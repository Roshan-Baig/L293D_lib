#include "L293D_lib.h"

L293D::L293D(byte pin1, byte pin2, byte pin3, byte pin4, byte EN_1, byte EN_2, byte Speed) {
  this->pin1 = pin1;
  this->pin2 = pin2;
  this->pin3 = pin3;
  this->pin4 = pin4;
  this->EN_1 = EN_1;
  this->EN_2 = EN_2;
  this->Speed = Speed;
  init();
}

void L293D::init() {
  pinMode(pin1, OUTPUT);
  pinMode(pin2, OUTPUT);
  pinMode(pin3, OUTPUT);
  pinMode(pin4, OUTPUT);
  pinMode(EN_1, OUTPUT);
  pinMode(EN_1, OUTPUT);
  Stop();
}

void L293D::Stop() {
  digitalWrite(pin1,LOW);//Writing a digital LOW to all pins associated with movement of motor driver causes all motors to stop
  digitalWrite(pin2,LOW);
  digitalWrite(pin3,LOW);
  digitalWrite(pin4,LOW);
}

void L293D::forward() {
  digitalWrite(pin1, HIGH);
  digitalWrite(pin2, LOW);
  digitalWrite(pin3, HIGH);
  digitalWrite(pin4, LOW);
}

void L293D::backward() {
  //reverse logic of above
  digitalWrite(pin1, LOW);
  digitalWrite(pin2, HIGH);
  digitalWrite(pin3, LOW);
  digitalWrite(pin4, HIGH);
}

void L293D::right() {
  digitalWrite(pin1, HIGH);
  digitalWrite(pin2, LOW);
  digitalWrite(pin3, LOW);
  digitalWrite(pin4, LOW);
}

void L293D::left() {
  digitalWrite(pin1, LOW);
  digitalWrite(pin2, LOW);
  digitalWrite(pin3, HIGH);
  digitalWrite(pin4, LOW);
}

void L293D::speedUp() {
  Speed += 10;
  analogWrite(EN_1, Speed);
  analogWrite(EN_2, Speed);
}

void L293D::slowDown() {
  Speed -= 10;
  analogWrite(EN_1, Speed);
  analogWrite(EN_2, Speed);
}

int L293D::getSpeed() {
  return Speed;
}
