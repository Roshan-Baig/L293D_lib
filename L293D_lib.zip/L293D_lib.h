#ifndef L293D_LIB_H
#define L293D_LIB_H

#include <Arduino.h>

class L293D {
  
  private:
    byte pin1;
    byte pin2;
    byte pin3;
    byte pin4;
    byte EN_1;
    byte EN_2;
    byte Speed;
    
  public:
    // Setup driver pins and call init()
    L293D(byte pin1, byte pin2, byte pin3, byte pin4, byte EN_1, byte EN_2, byte Speed);

    // Setup the driver as OUTPUT
    // and Stop all motors
    void init();
    
    // motors forward
    void forward();

    // motors backward
    void backward();
    // stop
    void Stop();
    //left
    void left();
    // right
    void right();
    // speedUp
    void speedUp();
    // slowDown
    void slowDown();
    // function to get the speed of robot
    int getSpeed();
};

#endif
